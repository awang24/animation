package cs3500.animator.view;

/**
 * Represents a general interface for a view. Encapsulates all types of views.
 */
public interface IView {
}
